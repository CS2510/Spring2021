import Component from "../component.js"

export default class ScreenCameraComponent extends Component {
  
  constructor(gameObject) {
    super(gameObject);
    
  }
}