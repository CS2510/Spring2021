export {default as MainScene} from "./main-scene.js"
