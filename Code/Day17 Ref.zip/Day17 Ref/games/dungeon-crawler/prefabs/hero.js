export default {
  name: "Hero", components: [
    {
      name: "KeyboardMoveComponent", args: [5]
    },
    { name: "DrawGeometryComponent", args: ["green"] },
    { name: "RectangleGeometryComponent", args: [75, 75] },
  ],
  children:[
    {
      gameObject:{
        name:"HeroHat",
        components:[
          {
            name:"DrawGeometryComponent", args:["brown"]
          },
          {
            name:"PolygonGeometryComponent", args:[[{x:-33,y:0},{x:33,y:0},{x:0,y:-33}]]
          }
        ]
      },x:0,y:-33
    }
  ]
}