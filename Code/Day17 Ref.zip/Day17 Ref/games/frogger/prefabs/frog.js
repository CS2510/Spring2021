export default {
  name: "frog",
  components: [
    { name: "DrawGeometryComponent", args: ["green"] },
    { name: "CircleGeometryComponent", args: [.5] },
    { name: "KeyboardBumpComponent", args: [1] }
  ],
  children: [
    {
      gameObject: {
        name: "LeftEye",
        components: [
          { name: "DrawGeometryComponent", args: ["white"] },
          { name: "CircleGeometryComponent", args: [.1] },
        ],
        children:[
          {
            gameObject: {
              name: "LeftEyePupil",
              components: [
                { name: "DrawGeometryComponent", args: ["black"] },
                { name: "CircleGeometryComponent", args: [.05] },
              ]
            },x:0,y:-.05
          },
        ]
      },x:-.4,y:-.35,sx:1.5,sy:1.5,r:.785
    },
    {
      gameObject: {
        name: "RightEye",
        components: [
          { name: "DrawGeometryComponent", args: ["white"] },
          { name: "CircleGeometryComponent", args: [.1] },
        ],
        children:[
          {
            gameObject: {
              name: "RightEyePupil",
              components: [
                { name: "DrawGeometryComponent", args: ["black"] },
                { name: "CircleGeometryComponent", args: [.05] },
              ]
            },x:0,y:-.05
          }
        ]
      },x:.4,y:-.35,sx:1.5,sy:1.5,r:-.785
    },
    
    
  ]
}